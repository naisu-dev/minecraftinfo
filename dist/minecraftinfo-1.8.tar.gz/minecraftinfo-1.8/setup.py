from setuptools import setup, find_packages

setup(
    name='minecraftinfo',
    version="1.8",
    description="Request information Minecraft JavaEdition and BedrockEdition",
    author='naisu',
    packages=find_packages(),
    license='MIT'
)
