from setuptools import setup, find_packages

setup(
    name='minecraftinfo',
    version="1.3",
    description="Request information Minecraft JavaEdition and BedrockEdition",
    author='naisu',
    packages=find_packages(),
    license='MIT'
)
